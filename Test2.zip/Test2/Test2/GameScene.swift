//
//  GameScene.swift
//  Test2
//
//  Created by MacStudent on 2019-06-14.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
    let panda = SKSpriteNode(imageNamed: "panda_01_idle_01")
    let coin = SKSpriteNode(imageNamed: "coin")
    let spikes = SKSpriteNode(imageNamed: "spikes")
    
    
    var lastUpdateTime: TimeInterval = 0
    var dt: TimeInterval = 0
    let pandaMovePointsPerSec: CGFloat = 480.0
    var velocity = CGPoint.zero
    let playableRect: CGRect
    var lastTouchLocation: CGPoint?
    
    
    override init(size: CGSize) {
        let maxAspectRatio:CGFloat = 16.0/9.0 // 1
        let playableHeight = size.width / maxAspectRatio // 2
        let playableMargin = (size.height-playableHeight)/2.0 // 3
        playableRect = CGRect(x: 0, y: playableMargin,
                              width: size.width,
                              height: playableHeight) // 4
        super.init(size: size) // 5
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented") // 6
    }
    
    override func didMove(to view: SKView) {
        backgroundColor = SKColor.black
        let background = SKSpriteNode(imageNamed: "bakground")
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5) // default
        background.position = CGPoint(x: size.width/2, y: size.height/2)
        // background.zRotation = CGFloat(M_PI) / 8
        background.zPosition = -1
        addChild(background)
        
        let mySize = background.size
        print("Size: \(mySize)")
        
        panda.position = CGPoint(x: 400, y: 450)
        // zombie.setScale(2) // SKNode method
        addChild(panda)
        
        coin.position.x = 1000
        coin.position.y = 1000
        coin.zPosition = 5
        addChild(coin)
        
      
        spawnspikes()
        
    }
    
   
    
    func spawnspikes() {
        let spikes = SKSpriteNode(imageNamed: "spikes")
        spikes.position = CGPoint(x: size.width + spikes.size.width/2, y: size.height/2)
        addChild(spikes)
        
        // 1
        let actionMidMove = SKAction.move(
            to: CGPoint(x: size.width/2,
                        y: playableRect.minY + spikes.size.height/2), duration: 1.0)
        // 2
        let actionMove = SKAction.move(
            to: CGPoint(x: -panda.size.width/2, y: spikes.position.y), duration: 1.0)
        // 3
        let wait = SKAction.wait(forDuration: 0.25)
        let sequence = SKAction.sequence([actionMidMove, actionMove])
        // 4
        spikes.run(sequence)
    }
    
    func pandaHit(spike: SKSpriteNode) {
        invincible = true
        let blinkTimes = 10.0
        let duration = 3.0
        let blinkAction = SKAction.customAction(withDuration: duration) { node, elapsedTime in
            let slice = duration / blinkTimes
            let remainder = Double(elapsedTime).truncatingRemainder(
                dividingBy: slice)
            node.isHidden = remainder > slice / 2
        }
        let setHidden = SKAction.run() { [weak self] in
            self?.panda.isHidden = false
            self?.invincible = false
        }
        panda.run(SKAction.sequence([blinkAction, setHidden]))
        
        //run(enemyCollisionSound)
        //loseCoin()
        
    }
    
    func checkCollisions() {
        
        
        var hitspike: [SKSpriteNode] = []
        enumerateChildNodes(withName: "spike") { node, _ in
            let spike = node as! SKSpriteNode
            if node.frame.insetBy(dx: 20, dy: 20).intersects(
                self.panda.frame) {
                hitspike.append(spike)
            }
        }
        for spike in hitspike {
            pandaHit(spike: spike)
            
        }
    }
    
    
}




